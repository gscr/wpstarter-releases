<?php

define('THEME_SLUG', 'wpstarter');
define('REMOTE_VERSION_URL', 'https://raw.githubusercontent.com/gscr/wpstarter-releases/refs/heads/main/version.json');

function theme_check_for_update($checked_data)
{
    if (empty($checked_data->checked)) {
        return $checked_data;
    }

    $theme_data = wp_get_theme(THEME_SLUG);
    $current_version = $theme_data->get('Version');

    $remote_version_data = fetch_remote_version_data();
    if (!$remote_version_data) {
        return $checked_data;
    }

    $remote_version = ltrim($remote_version_data->new_version, 'v');
    if (version_compare($current_version, $remote_version, '<')) {
        $checked_data->response[get_stylesheet()] = array(
            'theme' => THEME_SLUG,
            'new_version' => $remote_version,
            'url' => $remote_version_data->details_url,
            'package' => $remote_version_data->package,
        );
    }

    return $checked_data;
}
add_filter('pre_set_site_transient_update_themes', 'theme_check_for_update');

function theme_get_update_info($false, $action, $args)
{
    if (isset($args->slug) && $args->slug === THEME_SLUG) {
        $remote_version_data = fetch_remote_version_data();
        if (!$remote_version_data) {
            return false;
        }

        $remote_version = ltrim($remote_version_data->new_version, 'v');

        return array(
            'slug' => THEME_SLUG,
            'new_version' => $remote_version,
            'url' => $remote_version_data->details_url,
            'package' => $remote_version_data->package,
        );
    }

    return false;
}
add_filter('themes_api', 'theme_get_update_info', 10, 3);

function theme_update_button()
{
    if (current_user_can('update_themes')) {
        echo '<a href="' . esc_url(admin_url('update-core.php?force-check=1')) . '" id="theme-update-button" class="button button-primary">Check for Updates</a>';
    }
}

// Enqueue JavaScript and add button to the footer
function enqueue_theme_update_button_script()
{
    global $pagenow;

    if ($pagenow === 'themes.php') {
        // Output the button in the footer, hidden initially
        add_action('admin_footer', 'theme_update_button');

        // Enqueue JavaScript to move the button to the right place
        echo "
        <script type='text/javascript'>
            window.onload = function() {
                var themeRow = document.querySelector('.theme[data-slug=\"" . THEME_SLUG . "\"]'); 
                console.log(themeRow);
                var updateButton = document.getElementById('theme-update-button');
                
                if (themeRow && updateButton) {
                    var themeActions = themeRow.querySelector('.theme-actions'); // Find the action area for the theme
                    if (themeActions) {
                        themeActions.appendChild(updateButton); // Move button to theme actions
                    } else {
                        themeRow.appendChild(updateButton); // Fallback to append at the bottom of the row
                    }
                    updateButton.style.display = 'inline-block'; // Ensure button is visible
                }
            };
        </script>
        ";
    }
}
add_action('admin_enqueue_scripts', 'enqueue_theme_update_button_script');


function fetch_remote_version_data()
{
    $response = wp_remote_get(REMOTE_VERSION_URL);
    if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
        return false;
    }

    return json_decode(wp_remote_retrieve_body($response));
}
