const theme = require("./theme.json");
const tailpress = require("@jeffreyvr/tailwindcss-tailpress");
const colors = require("tailwindcss/colors");
const fs = require("fs");
const path = require("path");

/*
The following pulls the colours from the theme.json file and uses the naming scheme to add colour values as css variables.
This allows for dynamic changes to the overall colour scheme via the WP customiser.
*/
const themeJsonPath = path.resolve(__dirname, "./theme.json");
const themeJson = JSON.parse(fs.readFileSync(themeJsonPath, "utf8"));
const themeColours = themeJson.settings.color.palette.reduce((acc, color) => {
	// Use the colour slug as the key and convert the colour value to a CSS variable
	acc[color.slug] = `rgb(var(--color-${color.slug}) / <alpha-value>) `;
	// Add light and dark variants
	acc[
		`${color.slug}-light`
	] = `rgb(var(--color-${color.slug}-light) / <alpha-value>) `;
	acc[
		`${color.slug}-dark`
	] = `rgb(var(--color-${color.slug}-dark) / <alpha-value>) `;
	return acc;
}, {});

/** @type {import('tailwindcss').Config} */
module.exports = {
	content: ["./*.{php,twig}", "./**/*.{php,twig}", "./resources/*/*.{css,js}"],
	safelist: [
		{
			pattern: /align(full|wide|none|center|right)/,
		},
		{
			pattern: /wp-(block-button|caption|caption-text)/,
		},
		{
			pattern:
				/grid-cols-(1|2|3|4|5|6|left-xs|left-sm|right-xs|right-sm|left-focus|center-focus|right-focus)/,
			variants: ["md"],
		},
		{
			pattern: /p-(8|16|24)/,
		},
		{
			pattern: /w-(8|10|12|14|16)/,
		},
		{
			pattern: /gap-(8|16|24)/,
			variants: ["md"],
		},
		{
			pattern:
				/bg-(transparent|light|dark|gray-100|primary|secondary|tertiary)/,
			variants: ["hover"],
		},
		{
			pattern:
				/!?text-(transparent|light|dark|gray-100|primary|secondary|tertiary)/,
			variants: ["hover", "group-hover"],
		},
		{
			pattern:
				/border(?:-t|-l)?-(transparent|light|dark|gray-100|primary|secondary|tertiary)/,
			variants: ["hover"],
		},
		{
			pattern: /min-h-(44|64)/,
		},
		{
			pattern: /opacity-.*/,
		},
	],
	theme: {
		container: {
			padding: {
				DEFAULT: "1rem",
				sm: "2rem",
				lg: "0rem",
			},
		},
		colors: {
			transparent: "transparent",
			current: "currentColor",
			black: colors.black,
			white: colors.white,
			gray: colors.gray,
		},
		extend: {
			colors: themeColours, // Dynamic colour variable from top of file
			fontFamily: {
				sans: '"Noto Sans", sans-serif',
			},
			gridTemplateColumns: {
				"left-xs": "1fr 3fr",
				"left-sm": "1fr 2fr",
				"right-sm": "2fr 1fr",
				"right-xs": "3fr 1fr",
				"left-focus": "2fr 1fr 1fr",
				"center-focus": "1fr 2fr 1fr",
				"right-focus": "1fr 1fr 2fr",
			},
			boxShadow: {
				base: "0 1px 20px -3px rgb(0 0 0 / 0.075), 0 4px 10px -4px rgb(0 0 0 / 0.05)",
			},
		},
		screens: {
			xs: "30rem",
			sm: "37.5rem",
			md: "48rem",
			lg: tailpress.theme("settings.layout.contentSize", theme),
			xl: tailpress.theme("settings.layout.wideSize", theme),
			"2xl": "96rem",
		},
	},
	plugins: [
		tailpress.tailwind,
		require("tailwindcss-fluid-type")({
			settings: {
				fontSizeMin: 0.938, // 1rem === 16px
				fontSizeMax: 1.063, // 1.125rem === 18px
				ratioMin: 1.125, // Multiplicator Min
				ratioMax: 1.25, // Multiplicator Max
				screenMin: 20, // 20rem === 320px
				screenMax: 96, // 96rem === 1536px
				unit: "rem",
				extendValues: false,
			},
			values: {
				xs: [-2, 1.8],
				sm: [-1, 1.8],
				base: [0, 1.8],
				lg: [1, 1.6],
				xl: [2, 1.2],
				"2xl": [3, 1.2],
				"3xl": [4, 1.2],
				"4xl": [5, 1.1],
				"5xl": [6, 1.1],
				"6xl": [7, 1.1],
				"7xl": [8, 1],
				"8xl": [9, 1],
				"9xl": [10, 1],
			},
		}),
	],
	variants: {
		fluidType: ["responsive"],
	},
};
