// Initialize accordion functionality
function initAccordion() {
	document.querySelectorAll("[data-accordion-toggle]").forEach((toggle) => {
		toggle.removeEventListener("click", handleAccordionToggle);
		toggle.addEventListener("click", handleAccordionToggle);
	});
}

// Toggle accordion open/close
function handleAccordionToggle(event) {
	const toggle = event.currentTarget;
	const content = toggle.nextElementSibling;
	const chevron = toggle.querySelector(".chevron");

	if (content.classList.contains("max-h-0")) {
		content.classList.remove("max-h-0");
		content.classList.add("max-h-full");
		chevron.classList.add("rotate-180");
	} else {
		content.classList.remove("max-h-full");
		content.classList.add("max-h-0");
		chevron.classList.remove("rotate-180");
	}
}

// Initialise mobile menu toggle
function initMobileMenu() {
	const mainNavigation = document.querySelector("#primary-menu");
	const menuToggle = document.querySelector("#primary-menu-toggle");

	if (mainNavigation && menuToggle) {
		menuToggle.addEventListener("click", (e) => {
			e.preventDefault();
			mainNavigation.classList.toggle("hidden");
		});
	}
}

// Handle chevron click for submenus
function handleSubmenuToggle() {
	document.querySelectorAll("#primary-menu .chevron").forEach((chevron) => {
		chevron.removeEventListener("click", handleChevronClick);
		if (window.innerWidth <= 959) {
			chevron.addEventListener("click", handleChevronClick);
		}
	});
}

// Toggle submenu open/close
function handleChevronClick() {
	const subMenu = this.parentElement.nextElementSibling;
	if (subMenu && subMenu.classList.contains("submenu")) {
		subMenu.classList.toggle("mobile-show");
	}
}

// Dynamically add chevrons to sidebar menus and set up their functionality
function initSidebarMenu() {
	document
		.querySelectorAll("#sidebar .menu-item-has-children")
		.forEach((menuItem) => {
			// Create and append chevron
			const chevron = createChevronElement();
			menuItem.appendChild(chevron);

			// Add click event to chevron for toggling submenu
			chevron.addEventListener("click", (e) => {
				e.stopPropagation();
				toggleSubmenu(menuItem, chevron);
			});

			// Show submenu if current menu item is active
			if (menuItem.querySelector(".current-menu-item")) {
				const subMenu = menuItem.querySelector(".sub-menu");
				if (subMenu) {
					subMenu.classList.add("sub-show");
					chevron.classList.add("chevron-up");
				}
			}
		});
}

// Create a chevron element
function createChevronElement() {
	const chevron = document.createElement("div");
	chevron.innerHTML =
		'<svg width="18px" viewBox="0 0 48 30" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M5.64 0.36L24 18.68L42.36 0.36L48 6L24 30L0 6L5.64 0.36Z"/></svg>';
	chevron.style.cursor = "pointer";
	chevron.classList.add("chevron");
	return chevron;
}

// Toggle submenu open/close
function toggleSubmenu(menuItem, chevron) {
	const subMenu = menuItem.querySelector(".sub-menu");
	if (subMenu) {
		subMenu.classList.toggle("sub-show");
		chevron.classList.toggle("chevron-up");
	}
}

function initTabs() {
	const tabItems = document.querySelectorAll(".st-block-tab-item");
	const tabIndicators = document.querySelector(".tab-indicators");
	const backArrow = document.querySelector(".tab-back-arrow");
	const forwardArrow = document.querySelector(".tab-forward-arrow");
	const tabIndicatorsWrapper = document.querySelector(
		".tab-indicators-wrapper"
	);

	let isDragging = false;
	let startX;
	let scrollLeft;

	if (!tabItems.length || !tabIndicators) return; // Exit if no tabs are present

	// Function to set active tab and display content
	function activateTab(index) {
		// Hide all tabs
		tabItems.forEach((item) => item.classList.add("hidden"));

		// Remove active state from all indicators
		const indicatorItems = tabIndicators.querySelectorAll(".tab-indicator");
		indicatorItems.forEach((indicator) =>
			indicator.classList.remove("active-tab")
		);

		// Show selected tab
		tabItems[index].classList.remove("hidden");

		// Set active state to the selected tab indicator
		indicatorItems[index].classList.add("active-tab");

		// Scroll the selected tab into view (center it horizontally if out of view)
		indicatorItems[index].scrollIntoView({
			behavior: "smooth",
			inline: "center",
		});
	}

	// Function to scroll tabs horizontally with arrows
	function scrollTabs(direction) {
		const scrollAmount = 150; // Adjust the scroll amount as needed
		if (direction === "forward") {
			tabIndicatorsWrapper.scrollBy({ left: scrollAmount, behavior: "smooth" });
		} else if (direction === "back") {
			tabIndicatorsWrapper.scrollBy({
				left: -scrollAmount,
				behavior: "smooth",
			});
		}
	}

	// Show or hide arrows based on scroll position
	function updateArrows() {
		const maxScrollLeft =
			tabIndicatorsWrapper.scrollWidth - tabIndicatorsWrapper.clientWidth;
		const scrollLeft = tabIndicatorsWrapper.scrollLeft;

		if (scrollLeft > 0) {
			backArrow.classList.remove("hidden");
		} else {
			backArrow.classList.add("hidden");
		}

		if (scrollLeft < maxScrollLeft) {
			forwardArrow.classList.remove("hidden");
		} else {
			forwardArrow.classList.add("hidden");
		}
	}

	// Handle mouse down and touch start for dragging
	function startDrag(e) {
		isDragging = true;
		tabIndicatorsWrapper.classList.add("scrolling"); // Optional: Add a class for styling during scroll
		startX = e.pageX || e.touches[0].pageX;
		scrollLeft = tabIndicatorsWrapper.scrollLeft;
	}

	// Handle mouse move and touch move for dragging
	function moveDrag(e) {
		if (!isDragging) return;
		e.preventDefault(); // Prevent text selection while dragging
		const x = e.pageX || e.touches[0].pageX;
		const walk = (x - startX) * 2; // Increase scroll speed if needed
		tabIndicatorsWrapper.scrollLeft = scrollLeft - walk;
	}

	// Stop dragging
	function stopDrag() {
		isDragging = false;
		tabIndicatorsWrapper.classList.remove("scrolling"); // Optional: Remove the class after scroll
	}

	// Attach event listeners for mouse and touch drag
	tabIndicatorsWrapper.addEventListener("mousedown", startDrag);
	tabIndicatorsWrapper.addEventListener("touchstart", startDrag);
	tabIndicatorsWrapper.addEventListener("mousemove", moveDrag);
	tabIndicatorsWrapper.addEventListener("touchmove", moveDrag);
	tabIndicatorsWrapper.addEventListener("mouseup", stopDrag);
	tabIndicatorsWrapper.addEventListener("mouseleave", stopDrag);
	tabIndicatorsWrapper.addEventListener("touchend", stopDrag);

	// Attach click event listeners to the back and forward arrows
	backArrow.addEventListener("click", () => scrollTabs("back"));
	forwardArrow.addEventListener("click", () => scrollTabs("forward"));

	// Attach scroll event to update arrow visibility
	tabIndicatorsWrapper.addEventListener("scroll", updateArrows);

	// Get all existing tab indicators created by the Twig template
	const indicatorItems = tabIndicators.querySelectorAll(".tab-indicator");

	if (!indicatorItems.length) return; // Exit if no indicators are present

	// Attach click event listeners to each tab indicator
	indicatorItems.forEach((indicator, index) => {
		indicator.addEventListener("click", () => {
			activateTab(index);
		});
	});

	// Activate the first tab by default
	activateTab(0);

	// Initial arrow update
	updateArrows();
}

// Observer for dynamically added content
function setupMutationObserver() {
	const observer = new MutationObserver((mutations) => {
		mutations.forEach((mutation) => {
			mutation.addedNodes.forEach((node) => {
				if (node.nodeType === Node.ELEMENT_NODE) {
					if (node.querySelector(".accordion")) {
						initAccordion();
					}
					if (node.querySelector(".st-block-tab")) {
						initTabs();
					}
				}
			});
		});
	});

	observer.observe(document.body, {
		childList: true,
		subtree: true,
	});
}

// Initialize everything on window load
window.addEventListener("load", () => {
	initAccordion();
	initMobileMenu();
	initSidebarMenu();
	handleSubmenuToggle();
	initTabs();

	// Reapply submenu toggle on window resize
	window.addEventListener("resize", handleSubmenuToggle);

	// Setup observer to watch for dynamically added content
	setupMutationObserver();
});
