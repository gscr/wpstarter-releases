<?php
/**
 * Template Name: Sidebar
 * Description: A Page Template with a sidebar.
 */

 namespace App;

use Timber\Timber;



$context = Timber::context();

// Get the sidebar position field value
$context['sidebar_position'] = get_field('sidebar_position') ? 'sidebar-right' : 'sidebar-left';

Timber::render([
    'templates/page-sidebar.twig'
], $context);