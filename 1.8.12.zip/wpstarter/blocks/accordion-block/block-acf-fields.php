<?php

acf_add_local_field_group(
    array(
        'key' => 'group_accordion_block',
        'title' => 'Accordion Block Fields',
        'fields' => array(
            array(
                'key' => 'st_accordion_fill',
                'label' => 'Style',
                'name' => 'accordion_fill',
                'type' => 'true_false',
                'ui' => 1,
                'default_value' => 0,
                'ui_on_text' => 'Filled',
                'ui_off_text' => 'Not Filled',
            ),
            array(
                'key' => 'st_accordion_fill_color',
                'label' => 'Accordion Heading Colour',
                'name' => 'accordion_fill_color_radio',
                'type' => 'radio',
                'choices' => array(
                    'transparent' => '',
                ),
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'st_accordion_fill',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
            ),
            array(
                'key' => 'st_accordion_fill_text_color',
                'label' => 'Accordion Heading Text Colour',
                'name' => 'accordion_fill_text_color',
                'type' => 'radio',
                'choices' => array(
                ),
                'default_value' => 'dark',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'st_accordion_fill',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'block',
                    'operator' => '==',
                    'value' => 'acf/accordion-block',
                ),
            ),
        ),
    )
);

add_filter('acf/load_field/name=accordion_fill_color_radio', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=accordion_fill_text_color', 'wd_acf_dynamic_colors_load');
