<?php

acf_add_local_field_group(
    array(
        'key' => 'group_scroll_container_block',
        'title' => 'Scroll Container Block Fields',
        'fields' => array(
            array(
                'key' => 'st_scroll_min_width',
                'label' => 'Minimum Width (px)',
                'name' => 'scroll_min_width',
                'type' => 'number',
                'instructions' => 'Set the minimum width in pixels. When the screen is smaller than this width, content will scroll horizontally.',
                'required' => 1,
                'default_value' => 768,
                'min' => 320,
                'max' => 2000,
                'step' => 1,
            ),
            array(
                'key' => 'st_scroll_container_background_color',
                'label' => 'Background Colour',
                'name' => 'scroll_container_background_color',
                'type' => 'radio',
                'choices' => array(
                    'transparent' => '',
                    'gray-50' => '',
                ),
                'default_value' => 'transparent',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
            ),
            array(
                'key' => 'st_scroll_container_padding',
                'label' => 'Container Padding',
                'name' => 'scroll_container_padding',
                'type' => 'radio',
                'choices' => array(
                    '0' => 'None',
                    '4' => 'Small',
                    '8' => 'Medium',
                    '16' => 'Large',
                ),
                'default_value' => '0',
                'wrapper' => array(
                    'class' => 'st-padding-picker',
                ),
            ),
            array(
                'key' => 'st_scroll_container_shadow',
                'label' => 'Show Shadow',
                'name' => 'scroll_container_shadow',
                'type' => 'true_false',
                'instructions' => 'Add shadow to indicate scrollable content',
                'ui' => 1,
                'ui_on_text' => 'On',
                'ui_off_text' => 'Off',
                'default_value' => 0,
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'block',
                    'operator' => '==',
                    'value' => 'acf/scroll-container-block',
                ),
            ),
        ),
    )
);

add_filter('acf/load_field/name=scroll_container_background_color', 'wd_acf_dynamic_colors_load');
