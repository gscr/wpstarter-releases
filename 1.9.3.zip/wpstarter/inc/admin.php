<?php
/**
 * Adds the megamenu option to the menu item custom fields.
 *
 */
function st_add_megamenu_option_to_menu($item_id, $item, $depth, $args, $id) {
    $megamenu = get_post_meta($item_id, '_menu_item_megamenu', true);
    ?>
    <p class="field-megamenu description description-wide" style="display: none;" id="field-megamenu-<?php echo $item_id; ?>">
        <label for="edit-menu-item-megamenu-<?php echo $item_id; ?>">
            <input type="checkbox" id="edit-menu-item-megamenu-<?php echo $item_id; ?>" class="widefat code edit-menu-item-custom" name="menu-item-megamenu[<?php echo $item_id; ?>]" <?php checked($megamenu, 'yes'); ?> />
            Enable Megamenu
        </label>
    </p>
    <?php
}

/**
 * Enqueues the JavaScript code for handling the megamenu option.
 */
function st_enqueue_nav_menu_js() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Check if the primary menu is selected
            var primaryMenuSelected = $('#locations-primary').is(':checked');
            if (primaryMenuSelected) {
                // Iterate over each menu item
                $('#menu-to-edit li.menu-item').each(function(index, element) {
                    // Check if the item is a top-level item
                    if ($(this).hasClass('menu-item-depth-0')) {
                        // Assume it has no children initially
                        var hasChildren = false;
                        // Look ahead to the next item in the list to see if it's a child
                        var $nextItem = $(this).next('li.menu-item');
                        if ($nextItem.length > 0 && $nextItem.hasClass('menu-item-depth-1')) {
                            hasChildren = true;
                        }
                        // Show or hide the megamenu field based on whether it has children
                        $(this).find('.field-megamenu').toggle(hasChildren);
                    } else {
                        // Hide the megamenu option for non-top-level items
                        $(this).find('.field-megamenu').hide();
                    }
                });
            } else {
                // Hide the megamenu option if not the primary menu
                $('.field-megamenu').hide();
            }
        });
    </script>
    <?php
}

/**
 * Saves the megamenu option for a menu item.
 *
 */
function st_save_megamenu_option($menu_id, $menu_item_db_id, $args) {
    // Check if the megamenu option is set in the request
    if (isset($_REQUEST['menu-item-megamenu'][$menu_item_db_id])) {
        // If the checkbox for this item was checked, save 'yes'
        update_post_meta($menu_item_db_id, '_menu_item_megamenu', 'yes');
    } else {
        // If the checkbox was not checked, delete the meta key
        delete_post_meta($menu_item_db_id, '_menu_item_megamenu');
    }
}

/**
 * Adds the 'has-megamenu' class to menu items with megamenu enabled.
 *
 */
function st_add_megamenu_class($classes, $item, $args, $depth) {
    // Check if the megamenu option is enabled for this item
    $is_megamenu = get_post_meta($item->ID, '_menu_item_megamenu', true);
    if ($is_megamenu === 'yes') {
        $classes[] = 'has-megamenu';
    }
    return $classes;
}

// Hook the functions to the appropriate actions
add_action('wp_nav_menu_item_custom_fields', 'st_add_megamenu_option_to_menu', 10, 5);
add_action('admin_footer-nav-menus.php', 'st_enqueue_nav_menu_js');
add_action('wp_update_nav_menu_item', 'st_save_megamenu_option', 10, 3);
add_filter('nav_menu_css_class', 'st_add_megamenu_class', 10, 4);


/**
 * Register menus dynamically based on categories and taxonomies.
 */
function register_dynamic_menus() {
	// Fetch categories
    $categories = get_categories();

    // Fetch all taxonomies, including custom ones
    $taxonomies = get_taxonomies(array('public' => true, 'show_in_nav_menus' => true), 'objects');

    // Prepare an array to hold the menu locations
    $menu_locations = array(
        'primary' => __('Primary Menu', 'st'),
    );

	// Loop through categories and register a menu for each
    foreach ($categories as $category) {
        // Exclude 'Uncategorized' category
        if ($category->slug === 'uncategorized' || $category->slug === 'uncategorised') {
            continue;
        }
        $menu_locations[$category->slug] = sprintf(__('Category: %s', 'st'), $category->name);
    }

    // Loop through taxonomies and register a menu for each
    foreach ($taxonomies as $taxonomy) {
        // Exclude the 'post_tag', 'category', and 'post_format' taxonomies
        if (in_array($taxonomy->name, array('post_tag', 'category', 'post_format'))) {
            continue;
        }

        // Get the terms of the taxonomy
        $terms = get_terms(array(
            'taxonomy' => $taxonomy->name,
            'hide_empty' => true,
        ));

        // Loop through the terms and register a menu for each
        foreach ($terms as $term) {
            $menu_locations[$taxonomy->name . '-' . $term->slug] = sprintf(__('Taxonomy: %s - %s', 'st'), $taxonomy->label, $term->name);
        }
    }

    // Register the menus
    register_nav_menus($menu_locations);
}

// Hook the function to 'init' with a priority greater than 10 to ensure it runs after custom cpt and taxonomies are registered
add_action('init', 'register_dynamic_menus', 20);