<?php
// Register ACF field group for Icon Content Block
acf_add_local_field_group(array(
    'key' => 'group_icon_content_block',
    'title' => 'Icon Content Block Fields',
    'fields' => array(
        array(
            'key' => 'st_icon_content_icon_color',
            'label' => 'Icon Colour',
            'name' => 'icon_color_radio',
            'type' => 'radio',
            'choices' => array(
                'transparent' => '',
                'gray-100' => '',
            ),
            'default_value' => 'dark',
            'wrapper' => array(
                'class' => 'st-colour-picker',
            ),
        ),
        array(
            'key' => 'st_icon_content_icon_background',
            'label' => 'Icon Background / Outline',
            'name' => 'icon_background_radio',
            'type' => 'radio',
            'choices' => array(
                'transparent' => '',
                'gray-100' => '',
            ),
            'default_value' => 'transparent',
            'wrapper' => array(
                'class' => 'st-colour-picker',
            ),
        ),
        array(
            'key' => 'st_icon_content_icon_fill_style',
            'label' => 'Fill Style',
            'name' => 'icon_fill_style',
            'type' => 'true_false',
            'ui' => 1,
            'ui_on_text' => 'Filled',
            'ui_off_text' => 'Outlined',
        ),
        array(
            'key' => 'st_icon_content_icon_size',
            'label' => 'Icon Size',
            'name' => 'icon_size_radio',
            'type' => 'radio',
            'choices' => array(
                '10' => 'Small',
                '12' => 'Medium',
                '14' => 'Large',
                '16' => 'XL',
            ),
            'default_value' => '8',
            'wrapper' => array(
                'class' => 'st-icon-picker',
            ),
        ),
        array(
            'key' => 'st_icon_content_icon_select',
            'label' => 'Icon Select',
            'name' => 'icon_select_radio',
            'type' => 'radio',
            'choices' => array(
                'info' => '',
                'question' => '',
                'right' => '',
                'location' => '',
                'mail' => '',
                'phone' => '',
                'references' => '',
                'exclamation' => '',
                'warning' => '',
                'conditions' => '',
            ),
            'default_value' => 'info',
            'wrapper' => array(
                'class' => 'st-icon-graphic-picker',
            ),
        ),
        array(
            'key' => 'st_icon_content_custom_svg',
            'label' => 'Custom Icon SVG',
            'name' => 'custom_svg',
            'type' => 'textarea',
            'instructions' => 'Paste your custom SVG code here.',
        ),
    ),
    'location' => array(
        array(
            array(
                'param' => 'block',
                'operator' => '==',
                'value' => 'acf/icon-content-block',
            ),
        ),
    ),
));

// Optionally, add filters to dynamically load colors if needed
add_filter('acf/load_field/name=icon_color_radio', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=icon_background_radio', 'wd_acf_dynamic_colors_load');