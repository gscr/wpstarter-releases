<?php
/**
 * WP Starter Theme functions and definitions
 *
 * @package WP_Starter_Theme
 */

// Define theme constants
define('THEME_VERSION', wp_get_theme()->get('Version'));
define('THEME_DIR', get_template_directory());
define('THEME_URI', get_template_directory_uri());

// Autoload dependencies
require_once __DIR__ . '/vendor/autoload.php';
Timber\Timber::init();

/**
 * Theme Setup
 */
add_action('after_setup_theme', function() {
    // Add theme supports
    add_theme_support('title-tag');
    add_theme_support('html5', [
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ]);
    
    add_theme_support('custom-logo');
    add_theme_support('post-thumbnails');
    add_theme_support('align-wide');
    add_theme_support('wp-block-styles');
    add_theme_support('editor-styles');
    
    // Editor styles
    add_editor_style('css/editor-style.css');
    
    // Load text domain
    load_theme_textdomain('wp-starter', get_template_directory() . '/languages');
});

/**
 * ACF Integration
 */
add_action('after_setup_theme', function() {
    if (!class_exists('ACF')) {
        return;
    }
    
    // Load main ACF fields file if it exists
    $acf_fields_path = THEME_DIR . '/inc/acf-fields.php';
    if (file_exists($acf_fields_path)) {
        require_once $acf_fields_path;
    }
}, 5);

// Load ACF block fields after ACF is initialized
add_action('acf/init', function() {
    if (!class_exists('ACF') || !is_dir(THEME_DIR . '/blocks')) {
        return;
    }
    
    // Load ACF block fields
    $iterator = new DirectoryIterator(THEME_DIR . '/blocks');
    foreach ($iterator as $item) {
        if ($item->isDir() && !$item->isDot()) {
            $block_fields = $item->getPathname() . '/block-acf-fields.php';
            if (file_exists($block_fields)) {
                require_once $block_fields;
            }
        }
    }
});

/**
 * Enqueue theme assets
 */
add_action('wp_enqueue_scripts', function() {
    // Main styles
    wp_enqueue_style(
        'wp-starter-style',
        st_asset('css/app.css'),
        [],
        THEME_VERSION
    );
    
    // Main scripts
    wp_enqueue_script(
        'wp-starter-script',
        st_asset('js/app.js'),
        [],
        THEME_VERSION,
        true
    );
    
    // Google Fonts
    wp_enqueue_style(
        'google-fonts',
        'https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,100..900;1,100..900&display=swap',
        [],
        null
    );
});

/**
 * Enqueue editor assets
 */
add_action('enqueue_block_editor_assets', function() {
    wp_enqueue_script(
        'wp-starter-editor',
        st_asset('js/app.js'),
        ['wp-blocks', 'wp-dom-ready', 'wp-edit-post'],
        THEME_VERSION,
        true
    );
    
    wp_enqueue_style(
        'wp-starter-editor-style',
        st_asset('css/editor-style.css'),
        [],
        THEME_VERSION
    );
});

/**
 * Enqueue admin assets
 */
add_action('admin_enqueue_scripts', function() {
    wp_enqueue_style(
        'wp-starter-admin',
        st_asset('css/admin-style.css'),
        [],
        THEME_VERSION
    );
});

/**
 * Performance optimizations
 */
add_action('wp_enqueue_scripts', function() {
    // Remove global styles
    wp_dequeue_style('global-styles');
    
    // Preconnect to external domains
    add_action('wp_head', function() {
        echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
        echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
    }, 1);
}, 20);

/**
 * Register widget areas
 */
add_action('widgets_init', function() {
    $widget_areas = [
        [
            'name'          => __('Page Sidebar', 'wp-starter'),
            'id'            => 'page-sidebar',
            'description'   => __('Widget area for the page sidebar.', 'wp-starter'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>',
        ],
        [
            'name'          => __('Footer Widget Area 1', 'wp-starter'),
            'id'            => 'footer-widget-1',
            'description'   => __('First footer widget area.', 'wp-starter'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>',
        ],
        [
            'name'          => __('Footer Widget Area 2', 'wp-starter'),
            'id'            => 'footer-widget-2',
            'description'   => __('Second footer widget area.', 'wp-starter'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>',
        ],
        [
            'name'          => __('Footer Widget Area 3', 'wp-starter'),
            'id'            => 'footer-widget-3',
            'description'   => __('Third footer widget area.', 'wp-starter'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>',
        ]
    ];
    
    foreach ($widget_areas as $widget_area) {
        register_sidebar($widget_area);
    }
});

/**
 * Timber context
 * Add global context variables for all templates
 */
add_filter('timber/context', function($context) {
    // Add menus to context
    $menus = get_registered_nav_menus();
    foreach ($menus as $location => $description) {
        $context['menu_' . $location] = Timber::get_menu($location);
    }
    
    // Add theme mods to context
    $context['logo'] = wp_get_attachment_image(get_theme_mod('custom_logo'), 'thumbnail');
    $context['header_text'] = get_theme_mod('theme_header_text', '');
    $context['header_link'] = get_theme_mod('theme_header_link', '');
    $context['footer_copy'] = get_theme_mod('theme_footer_copyright_text', '');
    $context['footer_text_area'] = get_theme_mod('theme_footer_text_area', '');
    
    // Add widget areas to context
    $context['page_sidebar_widget'] = Timber::get_widgets('page-sidebar');
    $context['footer_widget_1'] = Timber::get_widgets('footer-widget-1');
    $context['footer_widget_2'] = Timber::get_widgets('footer-widget-2');
    $context['footer_widget_3'] = Timber::get_widgets('footer-widget-3');
    
    return $context;
});

/**
 * Get asset URL with cache busting
 * 
 * @param string $path Path to the asset relative to the theme directory
 * @return string URL to the asset with versioning
 */
function st_asset($path) {
    $url = THEME_URI . '/' . ltrim($path, '/');
    
    // Add timestamp for development
    if (wp_get_environment_type() !== 'production') {
        $url = add_query_arg('t', time(), $url);
    }
    
    return $url;
}

/** 
 * Timber context
 * Add global context variables for Timber (items that are available in all templates)
 */
add_filter('timber/context', function ($context) {
	// Get all registered menus
	$menus = get_registered_nav_menus();

	// Loop through each registered menu and add it to the context
	foreach ($menus as $location => $description) {
		$context['menu_' . $location] = Timber::get_menu($location);
	}


	$context['logo'] = wp_get_attachment_image(get_theme_mod('custom_logo'), 'thumbnail');
	$context['header_text'] = get_theme_mod('theme_header_text', '');
	$context['header_link'] = get_theme_mod('theme_header_link', '');
	$context['footer_copy'] = get_theme_mod('theme_footer_copyright_text', '');
	$context['footer_text_area'] = get_theme_mod('theme_footer_text_area', '');
	$context['page_sidebar_widget'] = Timber::get_widgets('page-sidebar');
	$context['footer_widget_1'] = Timber::get_widgets('footer-widget-1');
	$context['footer_widget_2'] = Timber::get_widgets('footer-widget-2');
	$context['footer_widget_3'] = Timber::get_widgets('footer-widget-3');

	return $context;

});

/*
 * Includes
 */
require_once get_template_directory() . '/inc/customiser.php'; // Customiser settings
require_once get_template_directory() . '/inc/admin.php'; // Custom settings for WP admin
require_once get_template_directory() . '/inc/theme-updater.php';

/*
 * Add all block files in the blocks directory
 */
function register_acf_blocks()
{
	foreach ($blocks = new DirectoryIterator(__DIR__ . '/blocks') as $item) {
		// Check if block.json file exists in each subfolder.
		if (
			$item->isDir() && !$item->isDot()
			&& file_exists($item->getPathname() . '/block.json')
		) {
			// Register the block given the directory name within the blocks
			// directory.
			register_block_type_from_metadata($item->getPathname());
		}
	}
}

add_action('init', 'register_acf_blocks');

/*
 * ACF block registration
 */

/**
 * Render callback to prepare and display a registered block using Timber.
 *
 */
function st_acf_block_render_callback($attributes, $content = '', $is_preview = false, $post_id = 0, $wp_block = null)
{
	// Create the slug of the block using the name property in the block.json.
	$slug = str_replace('acf/', '', $attributes['name']);

	$context = Timber::context();

	// Store block attributes.
	$context['attributes'] = $attributes;
	$context['block_content'] = $content;

	// Store field values. These are the fields from your ACF field group for the block.
	$context['fields'] = get_fields();

	// Store whether the block is being rendered in the editor or on the frontend.
	$context['is_preview'] = $is_preview;

	// Render the block.
	Timber::render(
		'blocks/' . $slug . '/' . $slug . '.twig',
		$context
	);
}


/**
 * Generates a group hash by concatenating a prefix with the MD5 hash of the identifier and site URL.
 * __FILE__ is used to ensure that the hash is unique to the current file.
 *
 */
function generate_hash($prefix, $identifier, $file = __FILE__)
{
	return $prefix . md5($identifier . $file . site_url());
}

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://raw.githubusercontent.com/gscr/wpstarter-releases/refs/heads/main/version.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'wpstarter'
);


// Add IDs to headings

function add_heading_ids($content)
{
	$matches = [];
	// Use a more flexible regex to match headings
	preg_match_all('/<h([2-3])\b([^>]*)>(.*?)<\/h[2-3]>/', $content, $matches, PREG_SET_ORDER);

	$counter = 1;

	foreach ($matches as $match) {
		$level = $match[1];
		$attributes = $match[2];
		$title = $match[3];
		// Generate an ordered ID
		$id = 'h' . str_pad($counter, 2, '0', STR_PAD_LEFT);
		$counter++;

		// Replace the heading with the new ID added, keeping existing attributes
		$new_heading = '<h' . $level . ' id="' . $id . '"' . $attributes . '>' . $title . '</h' . $level . '>';
		$content = str_replace($match[0], $new_heading, $content);

		// Log the new heading
		error_log('New heading: ' . $new_heading);
	}

	// Log the final content
	error_log('Final content: ' . $content);

	return $content;
}

// Generate the Table of Contents
function generate_toc($content)
{
	$toc = '';
	$matches = [];
	// Adjust regex to match headings with the generated IDs
	preg_match_all('/<h([2-3])\b[^>]*id="(h\d{2})"[^>]*>(.*?)<\/h[2-3]>/', $content, $matches, PREG_SET_ORDER);

	if ($matches) {
		$toc .= '<nav id="gen-toc"><p class="my-0 font-bold">On this page</p><ul>';
		foreach ($matches as $match) {
			$level = $match[1] - 1;
			$id = $match[2];
			$title = $match[3];
			$toc .= '<li class="lvl' . $level . '"><a href="#' . $id . '">' . $title . '</a></li>';
		}
		$toc .= '</ul></nav>';
	}

	return $toc;
}


// Register the filter and function in Timber Twig
add_filter('timber/twig/filters', function ($filters) {
	$filters['add_heading_ids'] = [
		'callable' => 'add_heading_ids'
	];
	return $filters;
});

add_filter('timber/twig/functions', function ($functions) {
	$functions['generate_toc'] = [
		'callable' => 'generate_toc',
	];
	return $functions;
});


// Change oEmbed container to be responsive
function wpcode_snippet_oembed_defaults($sizes)
{
	return array(
		'width' => '100%',
		'height' => 0, // Set to 0 to maintain aspect ratio
	);
}

function wpstarter_embed_html($html)
{
	return '<div class="embed-responsive" style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">' .
		'<div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">' .
		// Add class for any iframe to make it responsive
		str_replace('<iframe', '<iframe style="width:100%;height:100%;"', $html) .
		'</div>' .
		'</div>';
}

add_filter('embed_oembed_html', 'wpstarter_embed_html', 10, 3);
add_filter('video_embed_html', 'wpstarter_embed_html');

// add cpt to category archives
function include_custom_post_types_in_archives($query)
{
	if (is_category() && $query->is_main_query() && !is_admin()) {
		// Add your custom post types to the query
		$custom_post_types = get_post_types(['public' => true, '_builtin' => false]); // Get all public, non-built-in post types
		$post_types = array_merge(['post'], $custom_post_types);
		$query->set('post_type', $post_types);
	}
}
add_action('pre_get_posts', 'include_custom_post_types_in_archives');


/*
 * Custom post type permalink with category
 * Specific to 'resources' cpt
 */
function custom_cpt_rewrite_rules($rules) {
    $new_rules = [];
    $categories = get_terms([
        'taxonomy' => 'category',
        'hide_empty' => false,
    ]);

    if ($categories && !is_wp_error($categories)) {
        foreach ($categories as $category) {
            // Match only URLs with 'resources' post type
            $new_rules['resources/' . $category->slug . '/([^/]+)/?$'] = 'index.php?post_type=resources&name=$matches[1]&category_name=' . $category->slug;
        }
    }

    return $new_rules + $rules; // Prepend the new rules to avoid conflicts
}
add_filter('rewrite_rules_array', 'custom_cpt_rewrite_rules');



function custom_cpt_permalink($post_link, $post) {
    if ('resources' === $post->post_type) {
        $terms = get_the_terms($post->ID, 'category');
        if ($terms && !is_wp_error($terms)) {
            $category_slug = $terms[0]->slug; // Use the first category assigned
            return home_url('/resources/' . $category_slug . '/' . $post->post_name . '/');
        } else {
            return home_url('/resources/uncategorized/' . $post->post_name . '/'); // Fallback
        }
    }
    return $post_link;
}
add_filter('post_type_link', 'custom_cpt_permalink', 10, 2);


function remove_page_conflict() {
    global $wp_rewrite;
    
    // Check if $wp_rewrite exists and has the rules property
    if (isset($wp_rewrite) && is_object($wp_rewrite) && property_exists($wp_rewrite, 'rules') && is_array($wp_rewrite->rules)) {
        foreach ($wp_rewrite->rules as $rule => $query) {
            if (is_string($query) && strpos($query, 'pagename') !== false && strpos($query, 'resources') !== false) {
                unset($wp_rewrite->rules[$rule]);
            }
        }
    }
}
add_action('init', 'remove_page_conflict');


