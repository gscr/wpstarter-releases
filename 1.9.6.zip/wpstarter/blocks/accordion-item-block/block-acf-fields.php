<?php

acf_add_local_field_group(array(
    'key' => 'group_accordion_item_block',
    'title' => 'Accordion Item Block Fields',
    'fields' => array(
        array(
            'key' => 'st_accordion_item_heading',
            'label' => 'Accordion Heading',
            'name' => 'accordion_item_heading',
            'default_value' => 'Accordion Item Heading',
            'type' => 'text',
            'instructions' => 'Enter the heading for the accordion item.',
            'required' => true,
        ),
        array(
            'key' => 'st_accordion_item_include_in_toc',
            'label' => 'Include in Table of Contents',
            'name' => 'include_in_toc',
            'type' => 'true_false',
            'instructions' => 'If enabled, this accordion heading will be included in the page Table of Contents.',
            'default_value' => 0,
            'ui' => 1,
        )
    ),
    'location' => array(
        array(
            array(
                'param' => 'block',
                'operator' => '==',
                'value' => 'acf/accordion-item-block',
            ),
        ),
    ),
));
