document.addEventListener('DOMContentLoaded', function() {
    // Add expand/collapse all functionality
    const expandButtons = document.querySelectorAll('.st-accordion .expand-all');
    expandButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const accordion = this.closest('.st-accordion');
            const items = accordion.querySelectorAll('.accordion-item');
            const isExpanded = this.getAttribute('aria-expanded') === 'true';

            items.forEach(item => {
                const header = item.querySelector('.accordion-header');
                const content = item.querySelector('.accordion-content');
                
                if (isExpanded) {
                    content.style.maxHeight = '0';
                    header.setAttribute('aria-expanded', 'false');
                } else {
                    content.style.maxHeight = content.scrollHeight + 'px';
                    header.setAttribute('aria-expanded', 'true');
                }
            });

            // Toggle the button text and aria-expanded
            this.setAttribute('aria-expanded', !isExpanded);
            this.textContent = !isExpanded ? 'Collapse All' : 'Expand All';
        });
    });

    // Handle individual accordion items
    const accordionHeaders = document.querySelectorAll('.accordion-header');
    accordionHeaders.forEach(header => {
        header.addEventListener('click', function() {
            const content = this.nextElementSibling;
            const isExpanded = this.getAttribute('aria-expanded') === 'true';

            if (isExpanded) {
                content.style.maxHeight = '0';
            } else {
                content.style.maxHeight = content.scrollHeight + 'px';
            }

            this.setAttribute('aria-expanded', !isExpanded);
        });
    });
});
