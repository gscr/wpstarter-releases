<?php

acf_add_local_field_group(array(
    'key' => 'group_accordion_item_block',
    'title' => 'Accordion Item Block Fields',
    'fields' => array(
        array(
            'key' => 'st_accordion_item_heading',
            'label' => 'Accordion Heading',
            'name' => 'accordion_item_heading',
            'default_value' => 'Accordion Item Heading',
            'type' => 'text',
            'instructions' => 'Enter the heading for the accordion item.',
            'required' => true,
        )
    ),
    'location' => array(
        array(
            array(
                'param' => 'block',
                'operator' => '==',
                'value' => 'acf/accordion-item-block',
            ),
        ),
    ),
));
