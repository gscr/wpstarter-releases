<?php
require_once __DIR__ . '/vendor/autoload.php';
Timber\Timber::init();

/**
 * Theme setup.
 */
function st_setup()
{
	add_theme_support('title-tag');

	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		)
	);

	add_theme_support('custom-logo');
	add_theme_support('post-thumbnails');

	add_theme_support('align-wide');
	add_theme_support('wp-block-styles');

	add_theme_support('editor-styles');
	add_editor_style('css/editor-style.css'); 
}

add_action('after_setup_theme', 'st_setup');

/**
 * Enqueue theme assets.
 */
function st_enqueue_scripts()
{
	$theme = wp_get_theme();

	wp_enqueue_style('st', st_asset('css/app.css'), array(), $theme->get('Version'));
	wp_enqueue_script('st', st_asset('js/app.js'), array(), $theme->get('Version'));
	wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,100..900;1,100..900&display=swap', false);
}

add_action('wp_enqueue_scripts', 'st_enqueue_scripts');

/**
 * Enqueue script for Gutenberg editor.
 */
function st_enqueue_block_editor_assets()
{
    $theme = wp_get_theme();
    wp_enqueue_script('st-editor', st_asset('js/app.js'), array(), $theme->get('Version'), true);
}
add_action('enqueue_block_editor_assets', 'st_enqueue_block_editor_assets');

/**
 * Enqueue admin styles.
 */
function st_admin_style()
{
	wp_enqueue_style('st', st_asset('css/admin-style.css'));
}
add_action('admin_enqueue_scripts', 'st_admin_style');

/**
 * Preconnect for google fonts.
 */
function st_preconnect_google_fonts()
{
	echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
	echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
}
add_action('wp_head', 'st_preconnect_google_fonts');

/**
 * Disable global styles in head.
 */
function remove_global_styles()
{
	wp_dequeue_style('global-styles');
}

add_action('wp_enqueue_scripts', 'remove_global_styles');

/**
 * Get asset path.
 */
function st_asset($path)
{
	if (wp_get_environment_type() === 'production') {
		return get_stylesheet_directory_uri() . '/' . $path;
	}

	return add_query_arg('time', time(), get_stylesheet_directory_uri() . '/' . $path);
}
/**
 * Register widget areas for the footer.
 */
function st_register_footer_widget_areas()
{
	register_sidebar(
		array(
			'name' => __('Page sidebar', 'st'),
			'id' => 'page-sidebar',
			'description' => __('Widget area for the page sidebar.', 'st'),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h4 class="widget-title">',
			'after_title' => '</h4>',
		)
	);

	register_sidebar(
		array(
			'name' => __('Footer Widget Area 1', 'st'),
			'id' => 'footer-widget-1',
			'description' => __('Widget area for the footer.', 'st'),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h4 class="widget-title">',
			'after_title' => '</h4>',
		)
	);

	register_sidebar(
		array(
			'name' => __('Footer Widget Area 2', 'st'),
			'id' => 'footer-widget-2',
			'description' => __('Widget area for the footer.', 'st'),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h4 class="widget-title">',
			'after_title' => '</h4>',
		)
	);

	register_sidebar(
		array(
			'name' => __('Footer Widget Area 3', 'st'),
			'id' => 'footer-widget-3',
			'description' => __('Widget area for the footer.', 'st'),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h4 class="widget-title">',
			'after_title' => '</h4>',
		)
	);
}
add_action('widgets_init', 'st_register_footer_widget_areas');

/** 
 * Timber context
 * Add global context variables for Timber (items that are available in all templates)
 */
add_filter('timber/context', function ($context) {
	// Get all registered menus
    $menus = get_registered_nav_menus();

    // Loop through each registered menu and add it to the context
    foreach ($menus as $location => $description) {
        $context['menu_' . $location] = Timber::get_menu($location);
    }
	

	$context['logo'] = wp_get_attachment_image(get_theme_mod('custom_logo'), 'thumbnail');
	$context['header_text'] = get_theme_mod('theme_header_text', '');
	$context['header_link'] = get_theme_mod('theme_header_link', '');
	$context['footer_copy'] = get_theme_mod('theme_footer_copyright_text', '');
	$context['footer_text_area'] = get_theme_mod('theme_footer_text_area', '');
	$context['page_sidebar_widget'] = Timber::get_widgets('page-sidebar');
	$context['footer_widget_1'] = Timber::get_widgets('footer-widget-1');
	$context['footer_widget_2'] = Timber::get_widgets('footer-widget-2');
	$context['footer_widget_3'] = Timber::get_widgets('footer-widget-3');
	
	return $context;
	
});


/*
 * Includes
 */
require_once get_template_directory() . '/inc/customiser.php'; // Customiser settings
require_once get_template_directory() . '/inc/admin.php'; // Custom settings for WP admin
require_once get_template_directory() . '/inc/acf-fields.php'; // Custom settings for WP admin

/*
 * Add all block files in the blocks directory
 */
function register_acf_blocks()
{
	foreach ($blocks = new DirectoryIterator(__DIR__ . '/blocks') as $item) {
		// Check if block.json file exists in each subfolder.
		if (
			$item->isDir() && !$item->isDot()
			&& file_exists($item->getPathname() . '/block.json')
		) {
			// Register the block given the directory name within the blocks
			// directory.
			register_block_type_from_metadata($item->getPathname());
		}
	}
}

add_action('init', 'register_acf_blocks');

/*
 * Load acf block fields
 */
foreach ($blocks = new DirectoryIterator(__DIR__ . '/blocks') as $item) {
	if (
		$item->isDir() && !$item->isDot()
		&& file_exists($item->getPathname() . '/block-acf-fields.php')
	) {
		require_once $item->getPathname() . '/block-acf-fields.php';
	}
}

/**
 * Render callback to prepare and display a registered block using Timber.
 *
 */
function st_acf_block_render_callback($attributes, $content = '', $is_preview = false, $post_id = 0, $wp_block = null)
{
	// Create the slug of the block using the name property in the block.json.
	$slug = str_replace('acf/', '', $attributes['name']);

	$context = Timber::context();

	// Store block attributes.
	$context['attributes'] = $attributes;

	// Store field values. These are the fields from your ACF field group for the block.
	$context['fields'] = get_fields();

	// Store whether the block is being rendered in the editor or on the frontend.
	$context['is_preview'] = $is_preview;

	// Render the block.
	Timber::render(
		'blocks/' . $slug . '/' . $slug . '.twig',
		$context
	);
}


/**
 * Generates a group hash by concatenating a prefix with the MD5 hash of the identifier and site URL.
 * __FILE__ is used to ensure that the hash is unique to the current file.
 *
 */
function generate_hash($prefix, $identifier, $file = __FILE__) {
    return $prefix . md5($identifier . $file . site_url());
}

/**
 * Theme updater
 * https://github.com/YahnisElsts/plugin-update-checker
 */
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$themeSlug = 'wpstarter';
$publicJsonUrl = 'https://api.github.com/repos/gscr/wpstarter-releases/releases/latest';

$myUpdateChecker = PucFactory::buildUpdateChecker(
	$publicJsonUrl,
	__FILE__,
	$themeSlug
);