<?php

/**
 * The template for displaying all pages.
 *
 */

namespace App;

use Timber\Timber;

$context = Timber::context();

Timber::render([
    'templates/page.twig'
], $context);