// Navigation toggle
window.addEventListener("load", function () {
  let main_navigation = document.querySelector("#primary-menu");
  if (main_navigation) {
    document
      .querySelector("#primary-menu-toggle")
      .addEventListener("click", function (e) {
        e.preventDefault();
        main_navigation.classList.toggle("hidden");
      });
  }

  // Dynamically add chevrons and toggle functionality for submenus
  document
    .querySelectorAll("#sidebar .menu-item-has-children")
    .forEach(function (menuItem) {
      // Create and append the chevron
      const chevron = document.createElement("div");
      chevron.innerHTML =
        '<svg width="18px" viewbox="0 0 48 30" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M5.64 0.360001L24 18.68L42.36 0.360001L48 6L24 30L0 6L5.64 0.360001Z"/></svg>'; // Downward arrow
      chevron.style.cursor = "pointer";
      chevron.classList.add("chevron");
      menuItem.appendChild(chevron);

      // Toggle submenu on chevron click
      chevron.addEventListener("click", function (e) {
        e.stopPropagation(); // Prevent triggering the link
        const subMenu = menuItem.querySelector(".sub-menu");
        if (subMenu) {
          subMenu.classList.toggle("sub-show");
          // Toggle chevron direction
          chevron.classList.toggle("chevron-up");
        }
      });

      // Check if .menu-item-has-children contains a li with the class 'current-menu-item'
      const currentMenuItem = menuItem.querySelector(".current-menu-item");
      if (currentMenuItem) {
        const subMenu = menuItem.querySelector(".sub-menu");
        if (subMenu) {
          subMenu.classList.add("sub-show");
          chevron.classList.toggle("chevron-up");
        }
      }
    });

  document.querySelectorAll("[data-accordion-toggle]").forEach((toggle) => {
    toggle.addEventListener("click", () => {
      const content = toggle.nextElementSibling;
      const chevron = toggle.querySelector(".chevron");

      if (content.classList.contains("max-h-0")) {
        content.classList.remove("max-h-0");
        content.classList.add("max-h-screen");
        chevron.classList.add("rotate-180");
      } else {
        content.classList.remove("max-h-screen");
        content.classList.add("max-h-0");
        chevron.classList.remove("rotate-180");
      }
    });
  });
});
