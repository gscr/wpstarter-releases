// Initialize accordion functionality
function initAccordion() {
  document.querySelectorAll("[data-accordion-toggle]").forEach((toggle) => {
    toggle.removeEventListener("click", handleAccordionToggle);
    toggle.addEventListener("click", handleAccordionToggle);
  });
}

// Toggle accordion open/close
function handleAccordionToggle(event) {
  const toggle = event.currentTarget;
  const content = toggle.nextElementSibling;
  const chevron = toggle.querySelector(".chevron");

  if (content.classList.contains("max-h-0")) {
    content.classList.remove("max-h-0");
    content.classList.add("max-h-full");
    chevron.classList.add("rotate-180");
  } else {
    content.classList.remove("max-h-full");
    content.classList.add("max-h-0");
    chevron.classList.remove("rotate-180");
  }
}

// Initialise mobile menu toggle
function initMobileMenu() {
  const mainNavigation = document.querySelector("#primary-menu");
  const menuToggle = document.querySelector("#primary-menu-toggle");

  if (mainNavigation && menuToggle) {
    menuToggle.addEventListener("click", (e) => {
      e.preventDefault();
      mainNavigation.classList.toggle("hidden");
    });
  }
}

// Handle chevron click for submenus
function handleSubmenuToggle() {
  document.querySelectorAll("#primary-menu .chevron").forEach((chevron) => {
    chevron.removeEventListener("click", handleChevronClick);
    if (window.innerWidth <= 959) {
      chevron.addEventListener("click", handleChevronClick);
    }
  });
}

// Toggle submenu open/close
function handleChevronClick() {
  const subMenu = this.parentElement.nextElementSibling;
  if (subMenu && subMenu.classList.contains("submenu")) {
    subMenu.classList.toggle("mobile-show");
  }
}

// Dynamically add chevrons to sidebar menus and set up their functionality
function initSidebarMenu() {
  document
    .querySelectorAll("#sidebar .menu-item-has-children")
    .forEach((menuItem) => {
      // Create and append chevron
      const chevron = createChevronElement();
      menuItem.appendChild(chevron);

      // Add click event to chevron for toggling submenu
      chevron.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleSubmenu(menuItem, chevron);
      });
      console.log(menuItem);

      // Add click event to parent link if href is "#"
      const parentLink = menuItem.children[0]; // Get the first child (the <a> tag)
      if (
        parentLink &&
        parentLink.tagName === "A" &&
        parentLink.getAttribute("href") === "#"
      ) {
        parentLink.addEventListener("click", (e) => {
          e.preventDefault();
          toggleSubmenu(menuItem, chevron);
        });
      }

      // Show submenu if current menu item is active or has active children
      if (
        menuItem.querySelector(".current-menu-item") ||
        menuItem.classList.contains("current-menu-item")
      ) {
        const subMenu = menuItem.querySelector(".sub-menu");
        if (subMenu) {
          subMenu.classList.add("sub-show");
          chevron.classList.add("chevron-up");
        }
      }
    });
}

// Create a chevron element
function createChevronElement() {
  const chevron = document.createElement("div");
  chevron.innerHTML =
    '<svg width="18px" viewBox="0 0 48 30" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M5.64 0.36L24 18.68L42.36 0.36L48 6L24 30L0 6L5.64 0.36Z"/></svg>';
  chevron.style.cursor = "pointer";
  chevron.classList.add("chevron");
  return chevron;
}

// Toggle submenu open/close
function toggleSubmenu(menuItem, chevron) {
  const subMenu = menuItem.querySelector(".sub-menu");
  if (subMenu) {
    subMenu.classList.toggle("sub-show");
    chevron.classList.toggle("chevron-up");
  }
}

function initTabs() {
  const tabContainers = document.querySelectorAll(".st-block-tab");

  // Utility function to show/hide arrows based on scroll position
  function updateArrows(tabIndicatorsWrapper, backArrow, forwardArrow) {
    const maxScrollLeft =
      tabIndicatorsWrapper.scrollWidth - tabIndicatorsWrapper.clientWidth;
    const currentScrollLeft = tabIndicatorsWrapper.scrollLeft;

    backArrow.classList.toggle("hidden", currentScrollLeft <= 0);
    forwardArrow.classList.toggle("hidden", currentScrollLeft >= maxScrollLeft);
  }

  // Utility function to handle scrolling by clicking on arrows
  function scrollTabs(tabIndicatorsWrapper, direction) {
    const scrollAmount = 150;
    tabIndicatorsWrapper.scrollBy({
      left: direction === "forward" ? scrollAmount : -scrollAmount,
      behavior: "smooth",
    });
  }

  // Utility function to activate a specific tab
  function activateTab(tabItems, tabIndicators, index) {
    // Hide all tabs and remove active state from all indicators
    tabItems.forEach((item) => {
      item.classList.add("hide-tab");
      item.classList.remove("show-tab");
    });
    const indicatorItems = tabIndicators.querySelectorAll(".tab-indicator");
    indicatorItems.forEach((indicator) =>
      indicator.classList.remove("active-tab")
    );

    // Show the selected tab and activate the corresponding indicator
    tabItems[index].classList.remove("hide-tab");
    tabItems[index].classList.add("show-tab");
    indicatorItems[index].classList.add("active-tab");

    // Scroll the active indicator into view
    // indicatorItems[index].scrollIntoView({
    //   behavior: "smooth",
    //   inline: "center",
    // });
  }

  // Utility function to handle dragging of tab indicators
  function handleDrag(tabIndicatorsWrapper) {
    let isDragging = false;
    let startX, scrollLeft;

    function startDrag(e) {
      isDragging = true;
      tabIndicatorsWrapper.classList.add("scrolling");
      startX = e.pageX || e.touches[0].pageX;
      scrollLeft = tabIndicatorsWrapper.scrollLeft;
    }

    function moveDrag(e) {
      if (!isDragging) return;
      e.preventDefault();
      const x = e.pageX || e.touches[0].pageX;
      const walk = (x - startX) * 2;
      tabIndicatorsWrapper.scrollLeft = scrollLeft - walk;
    }

    function stopDrag() {
      isDragging = false;
      tabIndicatorsWrapper.classList.remove("scrolling");
    }

    tabIndicatorsWrapper.addEventListener("mousedown", startDrag);
    tabIndicatorsWrapper.addEventListener("touchstart", startDrag);
    tabIndicatorsWrapper.addEventListener("mousemove", moveDrag);
    tabIndicatorsWrapper.addEventListener("touchmove", moveDrag);
    tabIndicatorsWrapper.addEventListener("mouseup", stopDrag);
    tabIndicatorsWrapper.addEventListener("mouseleave", stopDrag);
    tabIndicatorsWrapper.addEventListener("touchend", stopDrag);
  }

  // Main loop through each tab block container
  tabContainers.forEach((container) => {
    const tabItems = container.querySelectorAll(".st-block-tab-item");
    const tabIndicators = container.querySelector(".tab-indicators");
    const backArrow = container.querySelector(".tab-back-arrow");
    const forwardArrow = container.querySelector(".tab-forward-arrow");
    const tabIndicatorsWrapper = container.querySelector(
      ".tab-indicators-wrapper"
    );

    if (!tabItems.length || !tabIndicators) return;

    // Attach event listeners to arrows
    backArrow.addEventListener("click", () =>
      scrollTabs(tabIndicatorsWrapper, "back")
    );
    forwardArrow.addEventListener("click", () =>
      scrollTabs(tabIndicatorsWrapper, "forward")
    );

    // Attach event listeners to each tab indicator
    const indicatorItems = tabIndicators.querySelectorAll(".tab-indicator");
    indicatorItems.forEach((indicator, index) => {
      indicator.addEventListener("click", () =>
        activateTab(tabItems, tabIndicators, index)
      );
    });

    // Initialize tabs and arrows
    activateTab(tabItems, tabIndicators, 0);
    tabItems.forEach((item, index) => {
      if (index !== 0) item.classList.add("hide-tab");
    });

    // Attach drag handling for tab indicators
    handleDrag(tabIndicatorsWrapper);

    // Update arrows initially and on scroll
    tabIndicatorsWrapper.addEventListener("scroll", () =>
      updateArrows(tabIndicatorsWrapper, backArrow, forwardArrow)
    );
    updateArrows(tabIndicatorsWrapper, backArrow, forwardArrow);
  });
}

// Observer for dynamically added content
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          if (node.querySelector(".accordion")) {
            initAccordion();
          }
          if (node.querySelector(".st-block-tab")) {
            initTabs();
          }
        }
      });
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
}

// Back to top button functionality
function initBackToTopButton(buttonId = "back-to-top", scrollTrigger = 300) {
  const btn = document.getElementById(buttonId);
  if (!btn) return;

  function toggleButton() {
    if (window.scrollY > scrollTrigger) {
      btn.classList.add("show");
    } else {
      btn.classList.remove("show");
    }
  }

  function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  window.addEventListener("scroll", toggleButton);
  btn.addEventListener("click", scrollToTop);
}

// Initialize everything on window load
window.addEventListener("load", () => {
  initAccordion();
  initMobileMenu();
  initSidebarMenu();
  handleSubmenuToggle();
  initTabs();
  initBackToTopButton();

  // Reapply submenu toggle on window resize
  window.addEventListener("resize", handleSubmenuToggle);

  // Setup observer to watch for dynamically added content
  setupMutationObserver();
});
